import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect

db = SQLAlchemy()
login_manager = LoginManager()
csrf = CSRFProtect()


def create_app():
    app = Flask(__name__, instance_relative_config=True)
    app.config.update(
        SECRET_KEY=os.getenv('SECRET_KEY', 'CHANGE-ME-IN-PRODUCTION'),
        SQLALCHEMY_DATABASE_URI=os.getenv('DATABASE_URL', 'sqlite:///royal_institute.db'),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE='Lax',
        SESSION_COOKIE_SECURE=os.getenv('COOKIE_SECURE', '0') == '1',
        MAX_CONTENT_LENGTH=8 * 1024 * 1024,
        INSTITUTE_NAME='Royal Institute of Safety & Technology',
        INSTITUTE_LOCATION='Takht Bhai',
        PUBLIC_BASE_URL=os.getenv('PUBLIC_BASE_URL', 'http://localhost:5000'),
    )
    os.makedirs(app.instance_path, exist_ok=True)
    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    login_manager.login_view = 'admin.login'

    from .models import Admin
    from .routes import main_bp, admin_bp
    app.register_blueprint(main_bp)
    app.register_blueprint(admin_bp, url_prefix='/admin')

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(Admin, int(user_id))

    @app.context_processor
    def inject_globals():
        from datetime import date
        return {'today': date.today().isoformat()}

    @app.after_request
    def security_headers(response):
        response.headers.setdefault('X-Content-Type-Options', 'nosniff')
        response.headers.setdefault('X-Frame-Options', 'SAMEORIGIN')
        response.headers.setdefault('Referrer-Policy', 'strict-origin-when-cross-origin')
        response.headers.setdefault('Permissions-Policy', 'camera=(), microphone=(), geolocation=()')
        if not app.debug:
            response.headers.setdefault('Strict-Transport-Security', 'max-age=31536000; includeSubDomains')
        return response

    with app.app_context():
        db.create_all()
        if not Admin.query.first():
            from werkzeug.security import generate_password_hash
            email = os.getenv('ADMIN_EMAIL', 'admin@royalinstitute.local').strip().lower()
            pw = os.getenv('ADMIN_PASSWORD', 'ChangeMe123!')
            db.session.add(Admin(email=email, password_hash=generate_password_hash(pw), full_name='Super Administrator', role='Super Admin'))
            db.session.commit()
    return app
