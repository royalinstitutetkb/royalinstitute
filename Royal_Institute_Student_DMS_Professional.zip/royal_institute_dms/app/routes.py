import io, os, shutil, tempfile
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from functools import wraps
from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file, current_app, abort
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from sqlalchemy import or_, func
from . import db
from .models import Admin, Student, Payment, Certificate, AuditLog
from .services import audit, generate_pin, certificate_pdf, receipt_pdf

main_bp=Blueprint('main', __name__)
admin_bp=Blueprint('admin', __name__)


def role_required(*roles):
    def deco(fn):
        @wraps(fn)
        @login_required
        def wrapped(*args, **kwargs):
            if current_user.role not in roles:
                abort(403)
            return fn(*args, **kwargs)
        return wrapped
    return deco

@main_bp.route('/')
def home(): return render_template('home.html')

@main_bp.route('/verify', methods=['GET','POST'])
def verify():
    result=None; searched=False; number=request.args.get('certificate_no','').strip().upper()
    if request.method=='POST':
        searched=True; number=request.form.get('certificate_no','').strip().upper()
    elif number: searched=True
    if number: result=Certificate.query.filter_by(certificate_no=number).first()
    return render_template('verify.html', result=result, searched=searched, number=number)

@main_bp.route('/verify/<certificate_no>')
def verify_certificate(certificate_no):
    cert=Certificate.query.filter_by(certificate_no=certificate_no.strip().upper()).first()
    return render_template('verify.html', result=cert, searched=True, number=certificate_no.strip().upper())

@main_bp.route('/student-portal', methods=['GET','POST'])
def student_portal():
    student=None; submitted=False
    if request.method=='POST':
        submitted=True; reg=request.form.get('registration_no','').strip().upper(); pin=request.form.get('access_pin','').strip()
        s=Student.query.filter_by(registration_no=reg).first()
        if s and s.access_pin_hash and check_password_hash(s.access_pin_hash,pin): student=s
    return render_template('student_portal.html', student=student, submitted=submitted)

@admin_bp.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        admin=Admin.query.filter_by(email=request.form.get('email','').strip().lower()).first()
        if admin and admin.is_active and check_password_hash(admin.password_hash, request.form.get('password','')):
            admin.last_login=datetime.utcnow(); db.session.commit(); login_user(admin); audit(admin,'LOGIN',details='Successful admin login',ip=request.remote_addr); db.session.commit(); return redirect(url_for('admin.dashboard'))
        flash('Invalid email or password.','danger')
    return render_template('login.html')

@admin_bp.route('/logout')
@login_required
def logout(): audit(current_user,'LOGOUT',ip=request.remote_addr); db.session.commit(); logout_user(); return redirect(url_for('main.home'))

@admin_bp.route('/')
@login_required
def dashboard():
    students=Student.query.order_by(Student.id.desc()).all()
    total=db.session.query(func.coalesce(func.sum(Student.total_fee),0)).scalar() or 0
    paid=db.session.query(func.coalesce(func.sum(Student.paid_fee),0)).scalar() or 0
    certs=Certificate.query.count(); valid=Certificate.query.filter_by(status='Valid').count()
    return render_template('dashboard.html', students=students[:25], total=total, paid=paid, balance=Decimal(str(total))-Decimal(str(paid)), certs=certs, valid=valid)

@admin_bp.route('/students/new', methods=['GET','POST'])
@role_required('Super Admin','Admin','Data Entry')
def new_student():
    if request.method=='POST':
        try:
            reg=request.form['registration_no'].strip().upper()
            if Student.query.filter_by(registration_no=reg).first(): raise ValueError('Registration number already exists.')
            total=Decimal(request.form.get('total_fee') or 0); paid=Decimal(request.form.get('paid_fee') or 0)
            if paid>total: raise ValueError('Paid fee cannot exceed total fee.')
            raw_pin=request.form.get('access_pin','').strip() or generate_pin()
            s=Student(registration_no=reg, full_name=request.form['full_name'].strip(), father_name=request.form.get('father_name'), cnic=request.form.get('cnic'), phone=request.form.get('phone'), email=request.form.get('email'), address=request.form.get('address'), date_of_birth=date.fromisoformat(request.form['date_of_birth']) if request.form.get('date_of_birth') else None, course=request.form['course'].strip(), batch=request.form.get('batch'), admission_date=date.fromisoformat(request.form['admission_date']) if request.form.get('admission_date') else None, completion_date=date.fromisoformat(request.form['completion_date']) if request.form.get('completion_date') else None, total_fee=total, paid_fee=paid, access_pin_hash=generate_password_hash(raw_pin), status=request.form.get('status','Active'), notes=request.form.get('notes'))
            db.session.add(s); db.session.flush()
            if paid>0:
                db.session.add(Payment(student_id=s.id,amount=paid,payment_date=date.today(),method='Opening Balance',receipt_no=f'OPEN-{s.id:06d}',remarks='Initial amount recorded at admission'))
            audit(current_user,'CREATE_STUDENT','Student',s.id,f'Registration {s.registration_no}',request.remote_addr); db.session.commit()
            flash(f'Student added. Student portal PIN: {raw_pin} — give this PIN securely to the student.','success')
            return redirect(url_for('admin.student_detail', student_id=s.id))
        except (InvalidOperation, ValueError) as e: db.session.rollback(); flash(f'Could not save student: {e}','danger')
        except Exception as e: db.session.rollback(); flash(f'Could not save student: {e}','danger')
    return render_template('student_form.html', student=None)

@admin_bp.route('/students/<int:student_id>/edit', methods=['GET','POST'])
@role_required('Super Admin','Admin','Data Entry')
def edit_student(student_id):
    s=Student.query.get_or_404(student_id)
    if request.method=='POST':
        try:
            s.full_name=request.form['full_name'].strip(); s.father_name=request.form.get('father_name'); s.cnic=request.form.get('cnic'); s.phone=request.form.get('phone'); s.email=request.form.get('email'); s.address=request.form.get('address'); s.course=request.form['course'].strip(); s.batch=request.form.get('batch'); s.status=request.form.get('status','Active'); s.notes=request.form.get('notes')
            s.date_of_birth=date.fromisoformat(request.form['date_of_birth']) if request.form.get('date_of_birth') else None
            s.admission_date=date.fromisoformat(request.form['admission_date']) if request.form.get('admission_date') else None
            s.completion_date=date.fromisoformat(request.form['completion_date']) if request.form.get('completion_date') else None
            total=Decimal(request.form.get('total_fee') or 0)
            if total < Decimal(str(s.paid_fee or 0)): raise ValueError('Total fee cannot be lower than amount already paid.')
            s.total_fee=total
            audit(current_user,'UPDATE_STUDENT','Student',s.id,f'Updated profile/fee total for {s.registration_no}',request.remote_addr); db.session.commit(); flash('Student updated.','success'); return redirect(url_for('admin.student_detail',student_id=s.id))
        except Exception as e: db.session.rollback(); flash(f'Could not update student: {e}','danger')
    return render_template('student_form.html', student=s, edit=True)

@admin_bp.route('/students/<int:student_id>')
@login_required
def student_detail(student_id):
    s=Student.query.get_or_404(student_id); return render_template('student_detail.html', student=s)

@admin_bp.route('/students/<int:student_id>/reset-pin', methods=['POST'])
@role_required('Super Admin','Admin')
def reset_pin(student_id):
    s=Student.query.get_or_404(student_id); pin=generate_pin(); s.access_pin_hash=generate_password_hash(pin); audit(current_user,'RESET_STUDENT_PIN','Student',s.id,f'New portal PIN generated for {s.registration_no}',request.remote_addr); db.session.commit(); flash(f'New student portal PIN: {pin}. Share it securely with the student.','success'); return redirect(url_for('admin.student_detail',student_id=s.id))

@admin_bp.route('/students/<int:student_id>/payment', methods=['POST'])
@role_required('Super Admin','Admin','Accountant')
def add_payment(student_id):
    s=Student.query.get_or_404(student_id)
    try:
        amount=Decimal(request.form['amount'])
        if amount<=0 or amount > s.balance: raise ValueError('Payment must be positive and cannot exceed outstanding balance.')
        receipt=request.form.get('receipt_no','').strip() or f'RCP-{datetime.utcnow():%Y%m%d%H%M%S}-{s.id}'
        if Payment.query.filter_by(receipt_no=receipt).first(): raise ValueError('Receipt number already exists.')
        p=Payment(student_id=s.id,amount=amount,payment_date=date.fromisoformat(request.form['payment_date']),method=request.form.get('method','Cash'),receipt_no=receipt,remarks=request.form.get('remarks'))
        s.paid_fee=(s.paid_fee or 0)+amount; db.session.add(p); db.session.flush(); audit(current_user,'RECORD_PAYMENT','Payment',p.id,f'Rs. {amount} for {s.registration_no}; receipt {receipt}',request.remote_addr); db.session.commit(); flash('Payment recorded.','success')
    except Exception as e: db.session.rollback(); flash(f'Invalid payment: {e}','danger')
    return redirect(url_for('admin.student_detail', student_id=student_id))

@admin_bp.route('/payments/<int:payment_id>/receipt')
@login_required
def payment_receipt(payment_id):
    p=Payment.query.get_or_404(payment_id); pdf=receipt_pdf(p); return send_file(pdf,mimetype='application/pdf',download_name=f'{p.receipt_no}.pdf',as_attachment=False)

@admin_bp.route('/students/<int:student_id>/certificate', methods=['POST'])
@role_required('Super Admin','Admin','Data Entry')
def add_certificate(student_id):
    s=Student.query.get_or_404(student_id)
    try:
        no=request.form['certificate_no'].strip().upper()
        if Certificate.query.filter_by(certificate_no=no).first(): raise ValueError('Certificate number already exists.')
        c=Certificate(student_id=s.id,certificate_no=no,issue_date=date.fromisoformat(request.form['issue_date']),course_title=request.form['course_title'],grade=request.form.get('grade'),duration=request.form.get('duration'),status=request.form.get('status','Valid'),verification_notes=request.form.get('verification_notes'))
        db.session.add(c); db.session.flush(); audit(current_user,'ISSUE_CERTIFICATE','Certificate',c.id,f'{no} issued to {s.registration_no}',request.remote_addr); db.session.commit(); flash('Certificate registered successfully. QR/PDF is ready.','success')
    except Exception as e: db.session.rollback(); flash(f'Could not add certificate: {e}','danger')
    return redirect(url_for('admin.student_detail',student_id=student_id))

@admin_bp.route('/certificates/<int:certificate_id>/pdf')
@login_required
def certificate_download(certificate_id):
    c=Certificate.query.get_or_404(certificate_id); pdf=certificate_pdf(c); return send_file(pdf,mimetype='application/pdf',download_name=f'{c.certificate_no}.pdf',as_attachment=False)

@admin_bp.route('/certificates/<int:certificate_id>/status', methods=['POST'])
@role_required('Super Admin','Admin')
def certificate_status(certificate_id):
    c=Certificate.query.get_or_404(certificate_id); c.status=request.form.get('status','Valid'); audit(current_user,'UPDATE_CERTIFICATE_STATUS','Certificate',c.id,f'Status set to {c.status}',request.remote_addr); db.session.commit(); flash('Certificate status updated.','success'); return redirect(url_for('admin.student_detail',student_id=c.student_id))

@admin_bp.route('/students/search')
@login_required
def search():
    q=request.args.get('q','').strip()
    students=Student.query.filter(or_(Student.registration_no.ilike(f'%{q}%'),Student.full_name.ilike(f'%{q}%'),Student.cnic.ilike(f'%{q}%'),Student.phone.ilike(f'%{q}%'))).order_by(Student.id.desc()).all() if q else []
    return render_template('search.html',students=students,q=q)

@admin_bp.route('/reports')
@login_required
def reports():
    total_students=Student.query.count(); completed=Student.query.filter_by(status='Completed').count(); active=Student.query.filter_by(status='Active').count(); outstanding=db.session.query(func.coalesce(func.sum(Student.total_fee-Student.paid_fee),0)).scalar() or 0; collected=db.session.query(func.coalesce(func.sum(Payment.amount),0)).scalar() or 0
    return render_template('reports.html',total_students=total_students,completed=completed,active=active,outstanding=outstanding,collected=collected)

@admin_bp.route('/export/students.xlsx')
@role_required('Super Admin','Admin','Accountant')
def export_students():
    from openpyxl import Workbook
    wb=Workbook(); ws=wb.active; ws.title='Students'
    headers=['Registration No','Name','Father Name','CNIC','Phone','Email','Course','Batch','Admission Date','Status','Total Fee','Paid Fee','Balance']
    ws.append(headers)
    for s in Student.query.order_by(Student.registration_no).all(): ws.append([s.registration_no,s.full_name,s.father_name,s.cnic,s.phone,s.email,s.course,s.batch,s.admission_date,s.status,float(s.total_fee or 0),float(s.paid_fee or 0),float(s.balance)])
    out=io.BytesIO(); wb.save(out); out.seek(0); audit(current_user,'EXPORT_STUDENTS',details='Exported student ledger',ip=request.remote_addr); db.session.commit(); return send_file(out,mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',download_name='royal_institute_students.xlsx')

@admin_bp.route('/audit')
@role_required('Super Admin')
def audit_logs():
    logs=AuditLog.query.order_by(AuditLog.id.desc()).limit(250).all(); return render_template('audit.html',logs=logs)

@admin_bp.route('/settings/password', methods=['GET','POST'])
@login_required
def password():
    if request.method=='POST':
        current=request.form.get('current'); new=request.form.get('new')
        if check_password_hash(current_user.password_hash,current) and new and len(new)>=12:
            current_user.password_hash=generate_password_hash(new); audit(current_user,'CHANGE_PASSWORD',details='Admin password changed',ip=request.remote_addr); db.session.commit(); flash('Password changed.','success'); return redirect(url_for('admin.dashboard'))
        flash('Current password is wrong or new password is shorter than 12 characters.','danger')
    return render_template('password.html')

@admin_bp.route('/backup')
@role_required('Super Admin')
def backup():
    uri=current_app.config['SQLALCHEMY_DATABASE_URI']
    if not uri.startswith('sqlite:///'): flash('For PostgreSQL, use managed database backups / pg_dump.','warning'); return redirect(url_for('admin.dashboard'))
    db_path=uri.replace('sqlite:///','',1)
    if not os.path.isabs(db_path): db_path=os.path.join(current_app.instance_path,db_path)
    if not os.path.exists(db_path): abort(404)
    audit(current_user,'BACKUP_DATABASE',details='SQLite database backup downloaded',ip=request.remote_addr); db.session.commit()
    return send_file(db_path,as_attachment=True,download_name=f'royal_institute_backup_{datetime.now():%Y%m%d_%H%M%S}.db')
