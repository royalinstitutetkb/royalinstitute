import io, os, secrets, sqlite3
from datetime import date
from decimal import Decimal
from flask import current_app, url_for
import qrcode
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from .models import AuditLog
from . import db


def audit(admin, action, entity_type=None, entity_id=None, details='', ip=None):
    db.session.add(AuditLog(admin_id=admin.id if admin else None, action=action, entity_type=entity_type,
                            entity_id=str(entity_id) if entity_id is not None else None, details=details, ip_address=ip))


def generate_pin():
    return ''.join(secrets.choice('0123456789') for _ in range(6))


def qr_png(data):
    qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=8, border=3)
    qr.add_data(data); qr.make(fit=True)
    img = qr.make_image(fill_color='#102A43', back_color='white')
    out = io.BytesIO(); img.save(out, format='PNG'); out.seek(0)
    return out


def certificate_pdf(cert):
    out = io.BytesIO()
    c = canvas.Canvas(out, pagesize=landscape(A4))
    W, H = landscape(A4)
    c.setStrokeColor(colors.HexColor('#1F4E79')); c.setLineWidth(4); c.rect(22, 22, W-44, H-44)
    c.setStrokeColor(colors.HexColor('#6C63B5')); c.setLineWidth(1); c.rect(30, 30, W-60, H-60)
    logo = os.path.join(current_app.root_path, 'static', 'logo.png')
    if os.path.exists(logo):
        c.drawImage(logo, 45, H-130, width=95, height=95, preserveAspectRatio=True, mask='auto')
    c.setFillColor(colors.HexColor('#17324D')); c.setFont('Helvetica-Bold', 22)
    c.drawCentredString(W/2, H-72, 'ROYAL INSTITUTE OF SAFETY & TECHNOLOGY')
    c.setFont('Helvetica-Bold', 13); c.setFillColor(colors.HexColor('#555555'))
    c.drawCentredString(W/2, H-96, 'TAKHT BHAI')
    c.setFont('Helvetica-Bold', 30); c.setFillColor(colors.HexColor('#1F4E79'))
    c.drawCentredString(W/2, H-150, 'CERTIFICATE OF COMPLETION')
    c.setFont('Helvetica', 13); c.setFillColor(colors.black)
    c.drawCentredString(W/2, H-185, 'This is to certify that')
    c.setFont('Helvetica-Bold', 25); c.drawCentredString(W/2, H-225, cert.student.full_name)
    c.setFont('Helvetica', 13)
    c.drawCentredString(W/2, H-255, f'Registration No. {cert.student.registration_no}')
    c.drawCentredString(W/2, H-285, 'has successfully completed the training/course')
    c.setFont('Helvetica-Bold', 18); c.setFillColor(colors.HexColor('#17324D'))
    c.drawCentredString(W/2, H-315, cert.course_title)
    c.setFont('Helvetica', 12); c.setFillColor(colors.black)
    c.drawCentredString(W/2, H-345, f'Duration: {cert.duration or "As per institute record"}     Grade: {cert.grade or "Completed"}')
    c.drawCentredString(W/2, H-368, f'Issued on: {cert.issue_date.strftime("%d %B %Y")}     Certificate No: {cert.certificate_no}')
    verify_url = url_for('main.verify_certificate', certificate_no=cert.certificate_no, _external=True)
    qr = qr_png(verify_url)
    c.drawImage(ImageReader(qr), W-155, 48, width=100, height=100, preserveAspectRatio=True)
    c.setFont('Helvetica', 8); c.drawCentredString(W-105, 40, 'Scan to verify')
    c.setFont('Helvetica-Bold', 10); c.drawString(60, 70, 'Authorized Signature')
    c.line(55, 66, 190, 66)
    c.setFont('Helvetica', 9); c.drawString(60, 52, 'Royal Institute, Takht Bhai')
    c.save(); out.seek(0); return out


def receipt_pdf(payment):
    out = io.BytesIO(); c = canvas.Canvas(out, pagesize=A4); W,H=A4
    c.setFillColor(colors.HexColor('#17324D')); c.setFont('Helvetica-Bold', 22)
    c.drawString(55,H-70,'ROYAL INSTITUTE OF SAFETY & TECHNOLOGY')
    c.setFont('Helvetica-Bold',15); c.drawString(55,H-95,'FEE PAYMENT RECEIPT — TAKHT BHAI')
    c.setStrokeColor(colors.HexColor('#6C63B5')); c.line(55,H-110,W-55,H-110)
    s=payment.student; rows=[('Receipt No.', payment.receipt_no or f'RCP-{payment.id:06d}'),('Registration No.',s.registration_no),('Student Name',s.full_name),('Course',s.course),('Payment Date',payment.payment_date.strftime('%d %B %Y')),('Method',payment.method),('Amount',f'Rs. {Decimal(str(payment.amount)):,.2f}'),('Remarks',payment.remarks or '—')]
    y=H-150; c.setFont('Helvetica',11)
    for k,v in rows:
        c.setFont('Helvetica-Bold',11); c.drawString(70,y,k+':'); c.setFont('Helvetica',11); c.drawString(200,y,str(v)); y-=35
    c.setFont('Helvetica-Bold',12); c.drawString(70,110,'Outstanding Balance:'); c.setFont('Helvetica',12); c.drawString(220,110,f'Rs. {s.balance:,.2f}')
    c.setFont('Helvetica',9); c.setFillColor(colors.grey); c.drawString(55,60,'Computer-generated receipt. Keep this receipt for your records.')
    c.save(); out.seek(0); return out
