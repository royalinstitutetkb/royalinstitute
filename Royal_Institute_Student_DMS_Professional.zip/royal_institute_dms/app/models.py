from datetime import datetime
from decimal import Decimal
from flask_login import UserMixin
from . import db

class Admin(UserMixin, db.Model):
    __tablename__ = 'admins'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(160), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(160), nullable=False, default='Administrator')
    role = db.Column(db.String(30), nullable=False, default='Admin')  # Super Admin / Admin / Accountant / Data Entry
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)

class Student(db.Model):
    __tablename__ = 'students'
    id = db.Column(db.Integer, primary_key=True)
    registration_no = db.Column(db.String(50), unique=True, nullable=False, index=True)
    full_name = db.Column(db.String(160), nullable=False)
    father_name = db.Column(db.String(160))
    cnic = db.Column(db.String(30), index=True)
    phone = db.Column(db.String(40))
    email = db.Column(db.String(160))
    address = db.Column(db.Text)
    date_of_birth = db.Column(db.Date)
    course = db.Column(db.String(160), nullable=False)
    batch = db.Column(db.String(80))
    admission_date = db.Column(db.Date)
    completion_date = db.Column(db.Date)
    status = db.Column(db.String(40), default='Active')
    total_fee = db.Column(db.Numeric(12, 2), default=0)
    paid_fee = db.Column(db.Numeric(12, 2), default=0)
    access_pin_hash = db.Column(db.String(255))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    certificates = db.relationship('Certificate', backref='student', cascade='all, delete-orphan')
    payments = db.relationship('Payment', backref='student', cascade='all, delete-orphan', order_by='Payment.payment_date.desc()')

    @property
    def balance(self):
        return Decimal(str(self.total_fee or 0)) - Decimal(str(self.paid_fee or 0))

class Payment(db.Model):
    __tablename__ = 'payments'
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False, index=True)
    amount = db.Column(db.Numeric(12, 2), nullable=False)
    payment_date = db.Column(db.Date, nullable=False)
    method = db.Column(db.String(60), default='Cash')
    receipt_no = db.Column(db.String(80), unique=True)
    remarks = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Certificate(db.Model):
    __tablename__ = 'certificates'
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False, index=True)
    certificate_no = db.Column(db.String(80), unique=True, nullable=False, index=True)
    issue_date = db.Column(db.Date, nullable=False)
    course_title = db.Column(db.String(160), nullable=False)
    grade = db.Column(db.String(30))
    duration = db.Column(db.String(80))
    status = db.Column(db.String(30), default='Valid')
    verification_notes = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.Integer, db.ForeignKey('admins.id'), nullable=True)
    action = db.Column(db.String(80), nullable=False)
    entity_type = db.Column(db.String(80))
    entity_id = db.Column(db.String(80))
    details = db.Column(db.Text)
    ip_address = db.Column(db.String(64))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
