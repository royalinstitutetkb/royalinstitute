# Production Deployment Checklist

## Domain & HTTPS
- Point the institute domain/subdomain to the server.
- Put Nginx, Caddy or a managed load balancer in front of Flask/Gunicorn.
- Enable TLS/HTTPS and set `COOKIE_SECURE=1`.
- Set `PUBLIC_BASE_URL=https://your-real-domain.example` so certificate QR codes resolve to the public portal.

## Database
- Use PostgreSQL for production.
- Restrict PostgreSQL to the application network; do not expose port 5432 publicly.
- Schedule daily encrypted backups and periodically test restore procedures.

## Credentials
- Change the initial admin email/password immediately.
- Generate a long random `SECRET_KEY`.
- Store secrets in environment variables or a managed secret store.
- Do not commit `.env` files or database backups to Git.

## Access control
- Give Super Admin access only to trusted management staff.
- Use Accountant for fee operations.
- Use Data Entry for student/certificate data entry.
- Review the audit log regularly.

## Certificate security
- Keep certificate numbers unique.
- Do not reuse a cancelled/replaced certificate number.
- Verify that every QR code resolves to the official institute domain.
- Public verification intentionally excludes CNIC, phone, address, fee and payment information.

## Student portal
- Give each student a unique 6-digit access PIN.
- If a PIN is compromised, reset it immediately from the student record.
- Registration number alone is not treated as authentication.
