# Royal Institute Student & Certificate Management System

Professional web-based database system for **Royal Institute of Safety & Technology, Takht Bhai**.

## Included 14 implementation stages

1. **Institute branding** — official Royal Institute logo integrated into the portal and generated certificates.
2. **Secure admin authentication** — hashed passwords, secure sessions, CSRF protection and security headers.
3. **Role-based administration** — Super Admin, Admin, Accountant and Data Entry roles.
4. **Student database** — registration number, biodata, CNIC, contact, course, batch, dates and status.
5. **Fee management** — total fee, paid fee, balance and complete payment history.
6. **Digital receipts** — payment receipt PDF generated from each recorded payment.
7. **Certificate registry** — unique certificate numbers, issue date, course, grade, duration and status.
8. **PDF certificates** — professional A4 landscape certificate generated directly by the system.
9. **QR verification** — every certificate PDF contains a QR code linked to the official verification URL.
10. **Public certificate verification** — anyone can verify a certificate without seeing private student data.
11. **Student portal** — student can access only their own record using registration number + secure 6-digit PIN.
12. **Reports & Excel export** — student ledger export and management summary.
13. **Audit & backup controls** — administrative activity log and SQLite backup download; PostgreSQL backup is recommended for production.
14. **Production deployment architecture** — PostgreSQL-ready configuration, HTTPS-ready cookies/headers, environment secrets and deployment files.

## Quick start

### Windows / Linux / macOS

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
```

Copy `.env.example` to `.env` and set a strong secret and admin password.

```bash
python run.py
```

Open the address printed by Flask. Default local admin email/password come from `.env`.

## Production

Use PostgreSQL, HTTPS behind a reverse proxy, a strong random `SECRET_KEY`, a non-default admin password, managed environment secrets, scheduled encrypted off-site backups, and restricted database/network access.

Example PostgreSQL setting:

`DATABASE_URL=postgresql+psycopg://USER:PASSWORD@HOST:5432/royal_institute`

Set `COOKIE_SECURE=1` when HTTPS is active and set `PUBLIC_BASE_URL` to the real public HTTPS address. QR codes will then point to the live verification portal.

## Certificate workflow

1. Admin creates student record.
2. Admin records fees/payments.
3. When eligible, admin registers a unique certificate number.
4. Admin opens **Certificate PDF**.
5. The generated PDF contains the institute logo and QR code.
6. Scanning the QR code opens `/verify/<certificate-number>`.
7. The public page displays only verification-safe information.
8. If the certificate is cancelled/replaced, the admin changes its status and the public verification result reflects that status.

## Security notes

- Passwords are stored as secure hashes, not plaintext.
- Admin forms use Flask-WTF CSRF protection.
- Student portal requires a second factor (access PIN) instead of exposing records by registration number alone.
- Public verification does not expose CNIC, phone, address, fee or payment history.
- Audit logs record sensitive administrative operations.
- For real student data, deploy behind HTTPS and use PostgreSQL with automated backups.
